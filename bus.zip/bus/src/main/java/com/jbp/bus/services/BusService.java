package com.jbp.bus.services;

import com.jbp.bus.entities.BusInfoEntity;
import com.jbp.bus.entities.BusStopEntity;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.stereotype.Service;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

@Service
public class BusService {

    public List<BusStopEntity> getBusStops(double minLat, double minLng, double maxLat, double maxLng) throws IOException {
        URLConnection url = new URL(String.format("http://apis.data.go.kr/1613000/BusSttnInfoInqireService/getSttnNoList?serviceKey=%s&cityCode=%s&numOfRows=%d&_type=json",
                "1nVxft83e9gIiYhsJPaLGa4NbL33i%2Bq2ovHq55XclW6wwxDw0klRxMdU3TEAKhNQAoz2w2%2FYGsudEjhg%2FcXD8Q%3D%3D",
                "22",
                10000)).openConnection();
        StringBuilder responseBuilder = new StringBuilder();
        try (InputStreamReader streamReader = new InputStreamReader(url.getInputStream())) {
            try (BufferedReader reader = new BufferedReader(streamReader)) {
                for (String line = reader.readLine(); line != null; line = reader.readLine()) {
                    responseBuilder.append(line);
                }
            }
        }

        JSONArray busArray = new JSONObject(responseBuilder.toString())
                .getJSONObject("response")
                .getJSONObject("body")
                .getJSONObject("items")
                .getJSONArray("item");
        List<BusStopEntity> busStopList = new ArrayList<>();
        for (int i = 0; i < busArray.length(); i++) {
            JSONObject busObject = busArray.getJSONObject(i);
            BusStopEntity busStop = BusStopEntity.build()
                    .setId(busObject.getString("nodeid"))
                    .setCode(busObject.has("nodeno") ? busObject.getInt("nodeno") : -1)
                    .setName(busObject.getString("nodenm"))
                    .setLat(busObject.getDouble("gpslati"))
                    .setLng(busObject.getDouble("gpslong"));
            if (busStop.getLat() > minLat &&
                    busStop.getLat() < maxLat &&
                    busStop.getLng() > minLng &&
                    busStop.getLng() < maxLng) {
                busStopList.add(busStop);
            }
        }
        return busStopList;
    }

    public List<BusInfoEntity> getBusInfos(int cityCode, String busStopId) throws
            IOException {
        List<BusInfoEntity> busInfoList = new ArrayList<>();
        URLConnection url = new URL(String.format("http://apis.data.go.kr/1613000/ArvlInfoInqireService/getSttnAcctoArvlPrearngeInfoList?serviceKey=%s&cityCode=%s&nodeId=%s&_type=json",
                "1nVxft83e9gIiYhsJPaLGa4NbL33i%2Bq2ovHq55XclW6wwxDw0klRxMdU3TEAKhNQAoz2w2%2FYGsudEjhg%2FcXD8Q%3D%3D",
                cityCode,
                busStopId)).openConnection();
        StringBuilder responseBuilder = new StringBuilder();
        try (InputStreamReader streamReader = new InputStreamReader(url.getInputStream())) {
            try (BufferedReader reader = new BufferedReader(streamReader)) {
                for (String line = reader.readLine(); line != null; line = reader.readLine()) {
                    responseBuilder.append(line);
                }
            }
        }
        JSONArray infoArray = new JSONObject(responseBuilder.toString())
                .getJSONObject("response")
                .getJSONObject("body")
                .getJSONObject("items")
                .getJSONArray("item");
        for (int i = 0; i < infoArray.length(); i++) {
            JSONObject infoObject = infoArray.getJSONObject(i);
            int routeType;
            switch (infoObject.getString("routetp")) {
                case "간선버스":
                    routeType = 0;
                    break;
                case "급행버스":
                    routeType = 1;
                    break;
                default:
                    routeType = -1;
            }
            int vehicleType;
            switch (infoObject.getString("vehicletp")) {
                case "일반차량":
                    vehicleType = 0;
                    break;
                case "저상버스":
                    vehicleType = 1;
                    break;
                default:
                    vehicleType = -1;
            }
            String busNumber;
            try {
                busNumber = infoObject.getString("routeno");
            } catch (JSONException ignored) {
                busNumber = String.valueOf(infoObject.getInt("routeno"));
            }
            BusInfoEntity entity = BusInfoEntity.build()
                    .setBusStopId(infoObject.getString("nodeid"))
                    .setBusStopName(infoObject.getString("nodenm"))
                    .setRouteId(infoObject.getString("routeid"))
                    .setBusNumber(busNumber)
                    .setRouteType(routeType)
                    .setVehicleType(vehicleType)
                    .setEtaCount(infoObject.getInt("arrprevstationcnt"))
                    .setEtaSecond(infoObject.getInt("arrtime"));
            busInfoList.add(entity);
        }
        busInfoList.sort(new Comparator<BusInfoEntity>() {
            @Override
            public int compare(BusInfoEntity o1, BusInfoEntity o2) {
                return o1.getEtaSecond() - o2.getEtaSecond();
            }
        });
        return busInfoList;
    }

}











