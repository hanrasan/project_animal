package com.jbp.bus.entities;

public class BusInfoEntity {
    public static BusInfoEntity build() {
        return new BusInfoEntity();
    }

    private String busStopId;   // nodeid
    private String busStopName; // nodenm
    private String routeId;     // routeid
    private String busNumber;   // routeno
    private int routeType;      // routetp *
    private int vehicleType;    // vehicletp *
    private int etaCount;       // arrprevstationcnt
    private int etaSecond;      // arrtime

    public String getBusStopId() {
        return busStopId;
    }

    public BusInfoEntity setBusStopId(String busStopId) {
        this.busStopId = busStopId;
        return this;
    }

    public String getBusStopName() {
        return busStopName;
    }

    public BusInfoEntity setBusStopName(String busStopName) {
        this.busStopName = busStopName;
        return this;
    }

    public String getRouteId() {
        return routeId;
    }

    public BusInfoEntity setRouteId(String routeId) {
        this.routeId = routeId;
        return this;
    }

    public String getBusNumber() {
        return busNumber;
    }

    public BusInfoEntity setBusNumber(String busNumber) {
        this.busNumber = busNumber;
        return this;
    }

    public int getRouteType() {
        return routeType;
    }

    public BusInfoEntity setRouteType(int routeType) {
        this.routeType = routeType;
        return this;
    }

    public int getVehicleType() {
        return vehicleType;
    }

    public BusInfoEntity setVehicleType(int vehicleType) {
        this.vehicleType = vehicleType;
        return this;
    }

    public int getEtaCount() {
        return etaCount;
    }

    public BusInfoEntity setEtaCount(int etaCount) {
        this.etaCount = etaCount;
        return this;
    }

    public int getEtaSecond() {
        return etaSecond;
    }

    public BusInfoEntity setEtaSecond(int etaSecond) {
        this.etaSecond = etaSecond;
        return this;
    }
}












