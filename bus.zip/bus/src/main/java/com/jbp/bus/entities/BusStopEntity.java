package com.jbp.bus.entities;

import java.util.Objects;

public class BusStopEntity {
    public static BusStopEntity build() {
        return new BusStopEntity();
    }

    private String id;
    private int code;
    private String name;
    private double lat;
    private double lng;

    public String getId() {
        return id;
    }

    public BusStopEntity setId(String id) {
        this.id = id;
        return this;
    }

    public int getCode() {
        return code;
    }

    public BusStopEntity setCode(int code) {
        this.code = code;
        return this;
    }

    public String getName() {
        return name;
    }

    public BusStopEntity setName(String name) {
        this.name = name;
        return this;
    }

    public double getLat() {
        return lat;
    }

    public BusStopEntity setLat(double lat) {
        this.lat = lat;
        return this;
    }

    public double getLng() {
        return lng;
    }

    public BusStopEntity setLng(double lng) {
        this.lng = lng;
        return this;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        BusStopEntity that = (BusStopEntity) o;
        return Objects.equals(id, that.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }
}