package com.jbp.bus.controllers;

import com.jbp.bus.entities.BusInfoEntity;
import com.jbp.bus.entities.BusStopEntity;
import com.jbp.bus.services.BusService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import java.io.IOException;
import java.util.List;

@Controller
@RequestMapping(value = "/")
public class HomeController {
    private final BusService busService;

    @Autowired
    public HomeController(BusService busService) {
        this.busService = busService;
    }

    @RequestMapping(value = "/", method = RequestMethod.GET)
    public String getIndex() {
        return "home/index";
    }

    @RequestMapping(value = "bus-stops", method = RequestMethod.GET)
    @ResponseBody
    public List<BusStopEntity> getBusStops(@RequestParam(value = "minLat") double minLat,
                                           @RequestParam(value = "minLng") double minLng,
                                           @RequestParam(value = "maxLat") double maxLat,
                                           @RequestParam(value = "maxLng") double maxLng) throws
            IOException {
        return this.busService.getBusStops(minLat, minLng, maxLat, maxLng);
    }

    @RequestMapping(value = "bus-infos", method = RequestMethod.GET)
    @ResponseBody
    public List<BusInfoEntity> getBusInfos(@RequestParam(value = "cityCode") int cityCode,
                                           @RequestParam(value = "id") String id) throws
            IOException {
        return this.busService.getBusInfos(cityCode, id);
    }
}













