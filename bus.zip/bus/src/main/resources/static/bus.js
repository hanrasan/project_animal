const infoContainerElement = document.getElementById('info-container');
const mapElement = document.getElementById('map');
const mapObject = new kakao.maps.Map(mapElement, {
    center: new kakao.maps.LatLng(35.8660426, 128.5938422),
    level: 3
});
const mapMarkers = [];

const addBusStop = (lat, lng) => {
    const marker = new kakao.maps.Marker({
        position: new kakao.maps.LatLng(lat, lng)
    }).setMap(mapObject);
    mapMarkers.push(marker);
};

const appendInfo = (infoObject) => {
    const infoElement = new DOMParser().parseFromString(`
        <li class="info loading" rel="info" 
                data-id="${infoObject['id']}" 
                data-lat="${infoObject['lat']}" 
                data-lng="${infoObject['lng']}">
            <div class="name-container">
                <span class="name">${infoObject['name']}</span>
                <span class="detail-container">
                    <span class="code">${infoObject['code']}</span>
                </span>
            </div>
            <ul class="bus-container" rel="bus-container">
                <span class="loading">데이터를 불러오고 있습니다...</span>            
            </ul>
        </li>`, 'text/html').querySelector('[rel="info"]');
    infoElement.addEventListener('click', () => {
        mapObject.setCenter(new kakao.maps.LatLng(infoObject['lat'], infoObject['lng']));
    });
    infoContainerElement.append(infoElement);
};

const clearInfo = () => {
    infoContainerElement.querySelectorAll(':scope > li.info').forEach(x => x.remove());
};

const clearMapMarkers = () => {
    mapMarkers.forEach(marker => marker?.setMap(undefined));
    mapMarkers.length = 0;
};

let loadBusStopsLifeCycle = 0;

const loadBusStops = () => {
    infoContainerElement.classList.add('hold');
    infoContainerElement.classList.remove('empty');
    let myCycle = ++loadBusStopsLifeCycle;
    const mapBound = mapObject.getBounds();
    const sw = mapBound.getSouthWest();
    const ne = mapBound.getNorthEast();
    const xhr = new XMLHttpRequest();
    xhr.open('GET', `./bus-stops?minLat=${sw.Ma}&minLng=${sw.La}&maxLat=${ne.Ma}&maxLng=${ne.La}`);
    xhr.onreadystatechange = () => {
        if (xhr.readyState === XMLHttpRequest.DONE) {
            infoContainerElement.classList.remove('hold');
            if (myCycle !== loadBusStopsLifeCycle) {
                return;
            }
            if (xhr.status >= 200 && xhr.status < 300) {
                const responseArray = JSON.parse(xhr.responseText);
                let count = 0;
                clearInfo();
                clearMapMarkers();
                for (let infoObject of responseArray) {
                    count++;
                    addBusStop(infoObject['lat'], infoObject['lng']);
                    appendInfo(infoObject);
                    const loop = setInterval(() => {
                        if (!loadBusInfos(22, infoObject['id'])) {
                            clearInterval(loop);
                        }
                    }, 5000);
                }
                if (count === 0) {
                    infoContainerElement.classList.add('empty');
                } else {
                    infoContainerElement.classList.remove('empty');
                }
            }
        }
    };
    xhr.send();
};

const loadBusInfos = (cityCode, id) => {
    const infoElement = infoContainerElement.querySelector(`[data-id="${id}"]`);
    if (!infoElement) {
        return false;
    }
    const busContainerElement = infoElement.querySelector('[rel="bus-container"]');
    const xhr = new XMLHttpRequest();
    xhr.open('GET', `./bus-infos?cityCode=${cityCode}&id=${id}`);
    xhr.onreadystatechange = () => {
        if (xhr.readyState === XMLHttpRequest.DONE) {
            if (xhr.status >= 200 && xhr.status < 300) {
                const responseArray = JSON.parse(xhr.responseText);
                busContainerElement.innerHTML = '';
                for (let busObject of responseArray) {
                    let routeType;
                    switch (busObject['routeType']) {
                        case 0 : routeType = '간선'; break;
                        case 1 : routeType = '급행'; break;
                        default: routeType = '알 수 없음';
                    }
                    let vehicleType;
                    switch (busObject['vehicleType']) {
                        case 0 : vehicleType = '일반'; break;
                        case 1 : vehicleType = '저상'; break;
                        default: vehicleType = '알 수 없음';
                    }
                    let etaCount;
                    switch (busObject['etaCount']) {
                        case 0 : etaCount = '진입 중'; break;
                        case 1 : etaCount = '전'; break;
                        case 2 : etaCount = '전전'; break;
                        default: etaCount = busObject['etaCount'] + '개 전';
                    }
                    const busElement = new DOMParser().parseFromString(`
                        <li class="bus" rel="bus">
                            <span class="number-container">
                                <span class="number">
                                    <span class="type ${routeType === '급행' ? 'rapid' : ''}">${routeType}</span>
                                    ${vehicleType === '저상' ? '<span class="low">저상</span>' : ''}
                                    <span class="number">${busObject['busNumber']}</span>
                                </span>
                            </span>
                            <span class="eta-primary">${Math.floor(busObject['etaSecond'] / 60)}분</span>
                            <span class="eta-secondary">${etaCount}</span>
                        </li>`, 'text/html').querySelector('[rel="bus"]');
                    busContainerElement.append(busElement);
                }
            }
        }
    };
    xhr.send();
    return true;
};

kakao.maps.event.addListener(mapObject, 'zoom_changed', () => {
    loadBusStops();
});

kakao.maps.event.addListener(mapObject, 'dragend', () => {
    loadBusStops();
});

window.addEventListener('load', () => {
    loadBusStops();
});